#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

#include "io.h"
#include "system.h"

#define ONE_MB (1024 * 1024)

void demo_256MB_memory_access() {
    uint32_t megabyte_count = 0;

    for (uint32_t i = 0; i < HPS_0_BRIDGES_SPAN; i += sizeof(uint32_t)) {

        // Print progress through 256 MB memory available through address span expander
        if ((i % ONE_MB) == 0) {
            printf("megabyte_count = %" PRIu32 "\n", megabyte_count);
            megabyte_count++;
        }

        uint32_t addr = HPS_0_BRIDGES_BASE + i;

        // Write through address span expander
        uint32_t write_data = i;
        IOWR_32DIRECT(addr, 0, write_data);

        // Read through address span expander
        uint32_t read_data = IORD_32DIRECT(addr, 0);

        // Check if read data is equal to written data
        assert(write_data == read_data);
    }
}

int main(void) {
    printf("test printf()\n");

    demo_256MB_memory_access();

    return EXIT_SUCCESS;
}
